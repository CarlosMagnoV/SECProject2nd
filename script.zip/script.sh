#!/bin/bash
java -jar /mnt/c/Users/Asus/Documents/GitHub/SECProject/Server.jar 3003&
java -jar /mnt/c/Users/Asus/Documents/GitHub/SECProject/Server.jar 3004 3003&
